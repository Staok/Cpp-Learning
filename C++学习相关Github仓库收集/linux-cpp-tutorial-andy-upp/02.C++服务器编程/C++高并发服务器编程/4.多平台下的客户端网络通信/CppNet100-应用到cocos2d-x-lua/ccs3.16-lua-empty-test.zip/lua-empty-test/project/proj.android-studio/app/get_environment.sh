#!/bin/bash

source ~/.bash_profile
echo $COCOS_CONSOLE_ROOT