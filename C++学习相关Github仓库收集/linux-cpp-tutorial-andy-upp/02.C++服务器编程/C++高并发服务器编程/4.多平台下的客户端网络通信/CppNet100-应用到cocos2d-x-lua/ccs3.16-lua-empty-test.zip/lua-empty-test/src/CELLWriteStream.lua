﻿CELLWriteStream = class("CELLWriteStream");

function CELLWriteStream:ctor(nSize)
	self._obj = CELLWriteStream_Create(nSize);
end

function CELLWriteStream:release()
	CELLWriteStream_Release(self._obj);
end

function CELLWriteStream:data()
	return self._obj;
end

function CELLWriteStream:setNetCmd(n)
	return CELLWriteStream_WriteUInt16(self._obj, n);
end

function CELLWriteStream:WriteInt8(n)
	return CELLWriteStream_WriteInt8(self._obj, n);
end

function CELLWriteStream:WriteInt16(n)
	return CELLWriteStream_WriteInt16(self._obj, n);
end

function CELLWriteStream:WriteInt32(n)
	return CELLWriteStream_WriteInt32(self._obj, n);
end

function CELLWriteStream:WriteInt64(n)
	return CELLWriteStream_WriteInt64(self._obj, n);
end

function CELLWriteStream:WriteUInt8(n)
	return CELLWriteStream_WriteUInt8(self._obj, n);
end

function CELLWriteStream:WriteUInt16(n)
	return CELLWriteStream_WriteUInt16(self._obj, n);
end

function CELLWriteStream:WriteUInt32(n)
	return CELLWriteStream_WriteUInt32(self._obj, n);
end

function CELLWriteStream:WriteUInt64(n)
	return CELLWriteStream_WriteUInt64(self._obj, n);
end

function CELLWriteStream:WriteFloat(n)
	return CELLWriteStream_WriteFloat(self._obj, n);
end

function CELLWriteStream:WriteDouble(n)
	return CELLWriteStream_WriteDouble(self._obj, n);
end

function CELLWriteStream:WriteString(n)
	return CELLWriteStream_WriteString(self._obj, n);
end

function CELLWriteStream:WriteInt32s(tabArr)
	local len = #tabArr
	--写入数组长度 无符号32位整数
	self:WriteUInt32(len);
	--写入数组元素
	for n = 1, len do
		self:WriteInt32(tabArr[n]);
	end
end