﻿CELLReadStream = class("CELLReadStream");

function CELLReadStream:ctor(nSize)
	self._obj = CELLReadStream_Create(nSize);
end

function CELLReadStream:release()
	CELLReadStream_Release(self._obj);
end

function CELLReadStream:getNetCmd()
	return CELLReadStream_ReadUInt16(self._obj);
end

function CELLReadStream:ReadInt8()
	return CELLReadStream_ReadInt8(self._obj);
end

function CELLReadStream:ReadInt16()
	return CELLReadStream_ReadInt16(self._obj);
end

function CELLReadStream:ReadInt32()
	return CELLReadStream_ReadInt32(self._obj);
end

function CELLReadStream:ReadInt64()
	return CELLReadStream_ReadInt64(self._obj);
end

function CELLReadStream:ReadUInt8()
	return CELLReadStream_ReadUInt8(self._obj);
end

function CELLReadStream:ReadUInt16()
	return CELLReadStream_ReadUInt16(self._obj);
end

function CELLReadStream:ReadUInt32()
	return CELLReadStream_ReadUInt32(self._obj);
end

function CELLReadStream:ReadUInt64()
	return CELLReadStream_ReadUInt64(self._obj);
end

function CELLReadStream:ReadFloat()
	return CELLReadStream_ReadFloat(self._obj);
end

function CELLReadStream:ReadDouble()
	return CELLReadStream_ReadDouble(self._obj);
end

function CELLReadStream:ReadString()
	return CELLReadStream_ReadString(self._obj);
end

function CELLReadStream:ReadInt32s()
	local tabArr = {}
	--读取数组长度 无符号32位整数
	local len = self:ReadUInt32(len);
	--写入数组元素
	for n = 1, len do
		tabArr[n] = self:ReadInt32();
	end
	return tabArr,len;
end