﻿CELLClient = class("CELLClient");

function CELLClient:ctor(cb, sendSize, recvSize)
	self._obj = CELLClient_Create(cb, sendSize,recvSize);
end

function CELLClient:Connect(ip, port)
	return CELLClient_Connect(self._obj, ip, port);
end

function CELLClient:OnRun()
	return CELLClient_OnRun(self._obj);
end

function CELLClient:Close()
	CELLClient_Close(self._obj);
end

function CELLClient:SendWriteStream(writeStream)
	return CELLClient_SendWriteStream(self._obj, writeStream:data())
end

--const char* data 
--int datalen
function CELLClient:SendData(data, datalen)
	return CELLClient_SendData(self._obj, data,datalen);
end
