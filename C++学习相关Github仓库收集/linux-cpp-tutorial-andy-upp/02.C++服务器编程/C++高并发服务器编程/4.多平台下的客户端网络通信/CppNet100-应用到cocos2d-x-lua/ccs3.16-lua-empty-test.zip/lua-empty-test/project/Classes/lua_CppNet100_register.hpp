#ifndef _LUA_CPP_NET_100_H_
#define _LUA_CPP_NET_100_H_

#include "cocos2d.h"
#include "scripting/lua-bindings/manual/CCLuaEngine.h"
#include "scripting/lua-bindings/manual/LuaBasicConversions.h"

#include"EasyTcpClient.hpp"
#include"CELLMsgStream.hpp"

#define EXPORT_LUA static

class NativeTCPClient : public EasyTcpClient
{
public:
	//��Ӧ������Ϣ
	virtual void OnNetMsg(netmsg_DataHeader* header)
	{
		if (_callBack > 0)
		{
			LuaEngine* engine = LuaEngine::getInstance();
			lua_State* L = engine->getLuaStack()->getLuaState();

			tolua_pushuserdata(L,header);
			//tolua_pushnumber(L, header->dataLength);
			lua_pushinteger(L, header->dataLength);
			engine->getLuaStack()->executeFunctionByHandler(_callBack, 2);
		}
	}

	void setCallBack(cocos2d::LUA_FUNCTION cb)
	{
		_callBack = cb;
	}
private:
	cocos2d::LUA_FUNCTION _callBack = 0;
};


////////////////////////Test
EXPORT_LUA int Add(lua_State* L)
{
	int argc = 0;
	argc = lua_gettop(L);
	if (argc == 2)
	{
		int a, b, c;
		if (luaval_to_int32(L, 1, &a))
		{
			//do something
		}
		b = lua_tointeger(L, 2);
		c = a + b;
		lua_pushinteger(L, c);
		return 1;
	}
	else {
		CCLOG("cpp Add argc != 2, argc = %d.", argc);
	}
	return 0;
}

EXPORT_LUA int SayHeiHei(lua_State* L)
{
	//const char* str = lua_tostring(L,1);
	//
	std::string s = lua_tostring(L, 1);

	s = "HeiHei " + s;

	lua_pushstring(L, s.c_str());

	return 1;
}

EXPORT_LUA int TestCall(lua_State* L)
{
	std::string s = luaL_checkstring(L, 1);
	
	cocos2d::LUA_FUNCTION cb = toluafix_ref_function(L, 2, 0);

	s = "HeiHei " + s;

	lua_pushstring(L, s.c_str());
	LuaEngine* engine = LuaEngine::getInstance();
	engine->getLuaStack()->executeFunctionByHandler(cb, 1);
	return 0;
}

/////////////////////////////CELLClient

EXPORT_LUA void* CELLClient_Create(cocos2d::LUA_FUNCTION cb, int sendSize, int recvSize)
{
	NativeTCPClient* obj = new NativeTCPClient();
	obj->setCallBack(cb);
	obj->InitSocket(sendSize, recvSize);
	return obj;
}

EXPORT_LUA bool CELLClient_Connect(NativeTCPClient* obj, const char* ip, unsigned short port)
{
	if (obj && ip)
		return SOCKET_ERROR != obj->Connect(ip, port);
	return false;
}

EXPORT_LUA bool CELLClient_OnRun(NativeTCPClient* obj)
{
	if (obj)
		return obj->OnRun();
	return false;
}

EXPORT_LUA void CELLClient_Close(NativeTCPClient* obj)
{
	if (obj)
	{
		obj->Close();
		delete obj;
	}
}

EXPORT_LUA int CELLClient_SendData(NativeTCPClient* obj, const char* data, int len)
{
	if (obj)
	{
		return obj->SendData(data, len);
	}
	return 0;
}

EXPORT_LUA int CELLClient_SendWriteStream(NativeTCPClient* obj, CELLWriteStream* wStream)
{
	if (obj && wStream)
	{
		wStream->finsh();
		return obj->SendData(wStream->data(), wStream->length());
	}
	return 0;
}
/////////////////////////////CELLStream
/////CELLWriteStream
EXPORT_LUA void* CELLWriteStream_Create(int nSize)
{
	CELLWriteStream* wStream = new CELLWriteStream(nSize);
	return wStream;
}
/////CELLReadStream
EXPORT_LUA void* CELLReadStream_Create(void* data)
{
	CELLReadStream* rStream = new CELLReadStream((netmsg_DataHeader*)data);
	return rStream;
}
/////////////////////////////CELLClient LUA
EXPORT_LUA int lua_CELLClient_Create(lua_State* L)
{
	cocos2d::LUA_FUNCTION cb;
	int sendSize;
	int recvSize;

	cb = toluafix_ref_function(L, 1, 0);
	sendSize = tolua_tonumber(L, 2, SEND_BUFF_SZIE);
	recvSize = tolua_tonumber(L, 3, RECV_BUFF_SZIE);

	void* obj = CELLClient_Create(cb, sendSize, recvSize);

	tolua_pushuserdata(L, obj);

	return 1;
}

EXPORT_LUA int lua_CELLClient_Connect(lua_State* L)
{
	NativeTCPClient* obj = nullptr;
	const char* ip = nullptr; 
	unsigned short port = 0;

	obj = (NativeTCPClient*)tolua_touserdata(L, 1, nullptr);
	ip = tolua_tostring(L, 2, nullptr);
	luaval_to_ushort(L, 3, &port);

	bool b = CELLClient_Connect(obj, ip, port);

	tolua_pushboolean(L,b);

	return 1;
}

EXPORT_LUA int lua_CELLClient_OnRun(lua_State* L)
{
	NativeTCPClient* obj = nullptr;

	obj = (NativeTCPClient*)tolua_touserdata(L, 1, nullptr);

	bool b = CELLClient_OnRun(obj);

	tolua_pushboolean(L, b);

	return 1;
}

EXPORT_LUA int lua_CELLClient_Close(lua_State* L)
{
	NativeTCPClient* obj = nullptr;

	obj = (NativeTCPClient*)tolua_touserdata(L, 1, nullptr);

	CELLClient_Close(obj);

	return 0;
}

EXPORT_LUA int lua_CELLClient_SendData(lua_State* L)
{
	NativeTCPClient* obj = nullptr;
	const char* ip = nullptr;
	int len = 0;

	obj = (NativeTCPClient*)tolua_touserdata(L, 1, nullptr);
	ip = tolua_tostring(L, 2, nullptr);
	if (!luaval_to_int32(L, 3, &len))
	{
		CCLOG("CELLClient_SendData argument #3[len] is  is not found.");
	}

	int n = CELLClient_SendData(obj, ip, len);

	tolua_pushnumber(L, n);

	return 1;
}

EXPORT_LUA int lua_CELLClient_SendWriteStream(lua_State* L)
{
	NativeTCPClient* obj1 = nullptr;
	CELLWriteStream* obj2 = nullptr;

	obj1 = (NativeTCPClient*)tolua_touserdata(L, 1, nullptr);
	obj2 = (CELLWriteStream*)tolua_touserdata(L, 2, nullptr);

	int n = CELLClient_SendWriteStream(obj1, obj2);

	tolua_pushnumber(L, n);

	return 1;
}
/////////////////////////////CELLStream Lua
/////CELLWriteStream Lua
EXPORT_LUA int lua_CELLWriteStream_Create(lua_State* L)
{
	//int nSize = lua_tointeger(L, 1);
	int nSize = tolua_tonumber(L, 1, 128);
	void* obj = CELLWriteStream_Create(nSize);
	tolua_pushuserdata(L, obj);
	return 1;
}

EXPORT_LUA int lua_CELLWriteStream_Release(lua_State* L)
{
	//ȡ����
	auto obj = (CELLWriteStream*)tolua_touserdata(L, 1, nullptr);
	if (obj)
		delete obj;
	return 0;
}

template<typename T>
EXPORT_LUA int lua_CELLWriteStream_Write(lua_State* L)
{
	//ȡ����
	auto obj = (CELLWriteStream*)tolua_touserdata(L, 1, nullptr);
	T n = (T)tolua_tonumber(L, 2, 0);
	//����
	bool b = false;
	if (obj)
		b = obj->Write(n);
	//���ؽ��
	tolua_pushboolean(L, b);
	return 1;
}

EXPORT_LUA int lua_CELLWriteStream_WriteInt8(lua_State* L)
{
	return lua_CELLWriteStream_Write<int8_t>(L);
}

EXPORT_LUA int lua_CELLWriteStream_WriteInt16(lua_State* L)
{
	return lua_CELLWriteStream_Write<int16_t>(L);
}

EXPORT_LUA int lua_CELLWriteStream_WriteInt32(lua_State* L)
{
	return lua_CELLWriteStream_Write<int32_t>(L);
}

EXPORT_LUA int lua_CELLWriteStream_WriteInt64(lua_State* L)
{
	return lua_CELLWriteStream_Write<int64_t>(L);
}

EXPORT_LUA int lua_CELLWriteStream_WriteUInt8(lua_State* L)
{
	return lua_CELLWriteStream_Write<uint8_t>(L);
}

EXPORT_LUA int lua_CELLWriteStream_WriteUInt16(lua_State* L)
{
	return lua_CELLWriteStream_Write<uint16_t>(L);
}

EXPORT_LUA int lua_CELLWriteStream_WriteUInt32(lua_State* L)
{
	return lua_CELLWriteStream_Write<uint32_t>(L);
}

EXPORT_LUA int lua_CELLWriteStream_WriteUInt64(lua_State* L)
{
	return lua_CELLWriteStream_Write<uint64_t>(L);
}

EXPORT_LUA int lua_CELLWriteStream_WriteFloat(lua_State* L)
{
	return lua_CELLWriteStream_Write<float>(L);
}

EXPORT_LUA int lua_CELLWriteStream_WriteDouble(lua_State* L)
{
	return lua_CELLWriteStream_Write<double>(L);
}

EXPORT_LUA int lua_CELLWriteStream_WriteString(lua_State* L)
{
	//ȡ����
	auto obj = (CELLWriteStream*)tolua_touserdata(L, 1, nullptr);
	const char* str = tolua_tostring(L, 2, nullptr);
	//����
	bool b = false;
	if (obj)
		b = obj->WriteString(str);
	//���ؽ��
	tolua_pushboolean(L, b);
	return 1;
}
/////CELLReadStream lua
EXPORT_LUA int lua_CELLReadStream_Create(lua_State* L)
{
	auto data = tolua_touserdata(L, 1, nullptr);
	void* obj = CELLReadStream_Create(data);
	tolua_pushuserdata(L, obj);
	return 1;
}

EXPORT_LUA int lua_CELLReadStream_Release(lua_State* L)
{
	//ȡ����
	auto obj = (CELLReadStream*)tolua_touserdata(L, 1, nullptr);
	if(obj)
		delete obj;
	return 0;
}

template<typename T>
EXPORT_LUA int lua_CELLReadStream_Read(lua_State* L)
{
	//ȡ����
	auto obj = (CELLReadStream*)tolua_touserdata(L, 1, nullptr);
	//����
	T n = 0;
	if (obj)
		obj->Read(n);
	//���ؽ��
	tolua_pushnumber(L, n);
	return 1;
}

EXPORT_LUA int lua_CELLReadStream_ReadInt8(lua_State* L)
{
	return lua_CELLReadStream_Read<int8_t>(L);
}

EXPORT_LUA int lua_CELLReadStream_ReadInt16(lua_State* L)
{
	return lua_CELLReadStream_Read<int16_t>(L);
}

EXPORT_LUA int lua_CELLReadStream_ReadInt32(lua_State* L)
{
	return lua_CELLReadStream_Read<int32_t>(L);
}

EXPORT_LUA int lua_CELLReadStream_ReadInt64(lua_State* L)
{
	return lua_CELLReadStream_Read<int64_t>(L);
}

EXPORT_LUA int lua_CELLReadStream_ReadUInt8(lua_State* L)
{
	return lua_CELLReadStream_Read<uint8_t>(L);
}

EXPORT_LUA int lua_CELLReadStream_ReadUInt16(lua_State* L)
{
	return lua_CELLReadStream_Read<uint16_t>(L);
}

EXPORT_LUA int lua_CELLReadStream_ReadUInt32(lua_State* L)
{
	return lua_CELLReadStream_Read<uint32_t>(L);
}

EXPORT_LUA int lua_CELLReadStream_ReadUInt64(lua_State* L)
{
	return lua_CELLReadStream_Read<uint64_t>(L);
}

EXPORT_LUA int lua_CELLReadStream_ReadFloat(lua_State* L)
{
	return lua_CELLReadStream_Read<float>(L);
}

EXPORT_LUA int lua_CELLReadStream_ReadDouble(lua_State* L)
{
	return lua_CELLReadStream_Read<double>(L);
}

EXPORT_LUA int lua_CELLReadStream_ReadString(lua_State* L)
{
	//ȡ����
	auto obj = (CELLReadStream*)tolua_touserdata(L, 1, nullptr);
	//����
	std::string n;
	if (obj)
		obj->ReadString(n);
	//���ؽ��
	//tolua_pushstring(L, n.c_str());
	tolua_pushcppstring(L, n);
	return 1;
}

////////////
EXPORT_LUA int lua_CppNet100_Test_register(lua_State* L)
{
	lua_register(L, "Add", Add);
	lua_register(L, "SayHi", SayHeiHei);
	lua_register(L, "TestCall", TestCall);
	return 0;
}

EXPORT_LUA int lua_CppNet100_CELL_register(lua_State* L)
{
	tolua_open(L);
	tolua_module(L, nullptr, 0);
	tolua_beginmodule(L, nullptr);
		tolua_function(L, "CELLClient_Create", lua_CELLClient_Create);
		tolua_function(L, "CELLClient_Connect", lua_CELLClient_Connect);
		tolua_function(L, "CELLClient_OnRun", lua_CELLClient_OnRun);
		tolua_function(L, "CELLClient_Close", lua_CELLClient_Close);
		tolua_function(L, "CELLClient_SendData", lua_CELLClient_SendData);
		tolua_function(L, "CELLClient_SendWriteStream", lua_CELLClient_SendWriteStream);
		////
		tolua_function(L, "CELLWriteStream_Create", lua_CELLWriteStream_Create);
		tolua_function(L, "CELLWriteStream_WriteInt8", lua_CELLWriteStream_WriteInt8);
		tolua_function(L, "CELLWriteStream_WriteInt16", lua_CELLWriteStream_WriteInt16);
		tolua_function(L, "CELLWriteStream_WriteInt32", lua_CELLWriteStream_WriteInt32);
		tolua_function(L, "CELLWriteStream_WriteInt64", lua_CELLWriteStream_WriteInt64);
		tolua_function(L, "CELLWriteStream_WriteUInt8", lua_CELLWriteStream_WriteUInt8);
		tolua_function(L, "CELLWriteStream_WriteUInt16", lua_CELLWriteStream_WriteUInt16);
		tolua_function(L, "CELLWriteStream_WriteUInt32", lua_CELLWriteStream_WriteUInt32);
		tolua_function(L, "CELLWriteStream_WriteUInt64", lua_CELLWriteStream_WriteUInt64);
		tolua_function(L, "CELLWriteStream_WriteFloat", lua_CELLWriteStream_WriteFloat);
		tolua_function(L, "CELLWriteStream_WriteDouble", lua_CELLWriteStream_WriteDouble);
		tolua_function(L, "CELLWriteStream_WriteString", lua_CELLWriteStream_WriteString);
		tolua_function(L, "CELLWriteStream_Release", lua_CELLWriteStream_Release);
		////
		tolua_function(L, "CELLReadStream_Create", lua_CELLReadStream_Create);
		tolua_function(L, "CELLReadStream_ReadInt8", lua_CELLReadStream_ReadInt8);
		tolua_function(L, "CELLReadStream_ReadInt16", lua_CELLReadStream_ReadInt16);
		tolua_function(L, "CELLReadStream_ReadInt32", lua_CELLReadStream_ReadInt32);
		tolua_function(L, "CELLReadStream_ReadInt64", lua_CELLReadStream_ReadInt64);
		tolua_function(L, "CELLReadStream_ReadUInt8", lua_CELLReadStream_ReadUInt8);
		tolua_function(L, "CELLReadStream_ReadUInt16", lua_CELLReadStream_ReadUInt16);
		tolua_function(L, "CELLReadStream_ReadUInt32", lua_CELLReadStream_ReadUInt32);
		tolua_function(L, "CELLReadStream_ReadUInt64", lua_CELLReadStream_ReadUInt64);
		tolua_function(L, "CELLReadStream_ReadFloat", lua_CELLReadStream_ReadFloat);
		tolua_function(L, "CELLReadStream_ReadDouble", lua_CELLReadStream_ReadDouble);
		tolua_function(L, "CELLReadStream_ReadString", lua_CELLReadStream_ReadString);
		tolua_function(L, "CELLReadStream_Release", lua_CELLReadStream_Release);
		////
	tolua_endmodule(L);
	return 0;
}

EXPORT_LUA int lua_CppNet100_register(lua_State* L)
{
	lua_CppNet100_Test_register(L);
	lua_CppNet100_CELL_register(L);
	return 0;
}

#endif // !_LUA_CPP_NET_100_H_
