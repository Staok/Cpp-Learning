﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Runtime.InteropServices;
using System;
using AOT;

public class CELLTCPCLient : MonoBehaviour {

    public delegate void OnNetMsgCallBack(IntPtr csObj, IntPtr data, int len);

    [MonoPInvokeCallback(typeof(OnNetMsgCallBack))]
    private static void OnNetMsgCallBack1(IntPtr csObj, IntPtr data, int len)
    {
        Debug.Log("OnNetMsgCallBack1:"+len);
    }

    [DllImport("CppNet100")]
    private static extern IntPtr CELLClient_Create(IntPtr csObj, OnNetMsgCallBack cb);

    [DllImport("CppNet100")]
    private static extern bool CELLClient_Connect(IntPtr cppClientObj, string ip, short port);

    [DllImport("CppNet100")]
    private static extern bool CELLClient_OnRun(IntPtr cppClientObj);

    [DllImport("CppNet100")]
    private static extern void CELLClient_Close(IntPtr cppClientObj);

    [DllImport("CppNet100")]
    private static extern int CELLClient_SendData(IntPtr cppClientObj, byte[] data, int len);

    ////////////
    private GCHandle _handleThis;
    // this对象的指针 在C++消息回调中传回
    IntPtr _csThisObj = IntPtr.Zero;
    //C++ NativeTCPClient 对象的指针
    IntPtr _cppClientObj = IntPtr.Zero;
    //
    public void Create()
    {
        _handleThis = GCHandle.Alloc(this);
        _csThisObj = GCHandle.ToIntPtr(_handleThis);
        _cppClientObj = CELLClient_Create(_csThisObj, OnNetMsgCallBack1);
    }

    public bool Connect(string ip, short port)
    {
        if (_cppClientObj == IntPtr.Zero)
            return false;

        return CELLClient_Connect(_cppClientObj, ip, port);
    }

    public bool OnRun()
    {
        if (_cppClientObj == IntPtr.Zero)
            return false;

        return CELLClient_OnRun(_cppClientObj);
    }

    public void Close()
    {
        if (_cppClientObj == IntPtr.Zero)
            return;

        CELLClient_Close(_cppClientObj);
        _cppClientObj = IntPtr.Zero;
    }

    public int SendData(byte[] data)
    {
        if (_cppClientObj == IntPtr.Zero)
            return 0;

        return CELLClient_SendData(_cppClientObj, data, data.Length);
    }

    ////////////

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
